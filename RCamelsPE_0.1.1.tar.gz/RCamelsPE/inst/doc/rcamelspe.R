## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = TRUE
)

## -----------------------------------------------------------------------------
# install.packages("remotes")
remotes::install_github("hllauca/RCamelsPE")

## ----setup--------------------------------------------------------------------
library(RCamelsPE)

## -----------------------------------------------------------------------------
set_camels_path("C:/Users/hllauca/Documents/CAMELS-PE")

## -----------------------------------------------------------------------------
stations <- read_metadata()

head(stations)

## -----------------------------------------------------------------------------
gauge_id <- 'PE_472935F2'

gauge_id

## -----------------------------------------------------------------------------
catchments <- read_geospatial("catchments")
gauges     <- read_geospatial("gauges")

## -----------------------------------------------------------------------------
plot_catchments(
  catchments = catchments,
  gauges = gauges,
  gauge_id = gauge_id
)

## -----------------------------------------------------------------------------
topo <- read_attributes("topographic")
head(topo)

## -----------------------------------------------------------------------------
clim <- read_attributes("climatic")
head(clim)

## -----------------------------------------------------------------------------
hyd   <- read_attributes(type = "hydrological")
land  <- read_attributes(type = "landcover")
geo   <- read_attributes(type = "geologic")
soil  <- read_attributes(type = "soil")
human <- read_attributes(type = "human_intervention")

## -----------------------------------------------------------------------------
topo_sel <- topo[topo$gauge_id == gauge_id, ]
clim_sel <- clim[clim$gauge_id == gauge_id, ]

topo_sel
clim_sel

## -----------------------------------------------------------------------------
ts <- read_timeseries(
  gauge_id = gauge_id,
  vars = c("date", "gauge_id", "prec", "flow_obs")
)

head(ts)

## -----------------------------------------------------------------------------
plot_timeseries(ts, variable = "prec", linewidth = 0.4)

## -----------------------------------------------------------------------------
plot_timeseries(ts, variable = "flow_obs")

## -----------------------------------------------------------------------------
# Read catchment area from topographic attributes
area_km2 <- topo_sel$area

# Convert flow from mm/day to m3/s
ts$flow_m3s <- ts$flow_obs * area_km2 * 1e6 / (1000 * 86400)

plot_timeseries(ts, variable = "flow_m3s")

## -----------------------------------------------------------------------------
ts_multi <- read_timeseries(
  gauge_id = c("PE_472A9204", "PE_210003"),
  vars = c("date", "gauge_id", "prec")
)

## -----------------------------------------------------------------------------
plot_timeseries(ts_multi, variable = "prec", facet = TRUE)

## -----------------------------------------------------------------------------
plot_timeseries(
  ts_multi,
  variable = "prec",
  gauge_id = "PE_472A9204"
)

## -----------------------------------------------------------------------------
library(RCamelsPE)

set_camels_path("C:/Users/hllauca/Documents/CAMELS-PE")

stations <- read_metadata()

gauge_id <- stations$gauge_id[1]

ts <- read_timeseries(
  gauge_id = gauge_id,
  vars = c("date", "gauge_id", "prec", "flow_obs")
)

plot_timeseries(ts, variable = "flow_obs")

